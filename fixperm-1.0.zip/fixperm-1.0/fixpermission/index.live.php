<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');

// Include CPPHP
require_once("inc/conf.inc.php");

// Set user language
include(SetLang());

// cPanel Header
cpHeader();

$Desped='';

$userhomedir = getenv('HOME');
$username=explode('/',$userhomedir)[2];



if (UserTheme() == 'x3') {
	echo '<div style="padding-left:20px;" class="h1Title"><img src="img/icon-x3.jpg" alt="" /> CpCleaner</div>';
	$Desped = 'style="padding-left:10px;"';
}



// Main content
if (empty($action)) {
    echo '
    <p '.$Desped.' id="descMysql" class="description">
        '.$LANG['homedes'].'
    </p>
	
    <br><br>
    <form action="index.live.php?action=fix" method="post" style="width: 100%;">
    	<div style="width: 250px; height:70px; margin: 0 auto;">
    		<input class="cpcprimary" value="'.$LANG['homebtn'].'" type="submit" style="width: 180px; height:70px; font-size: 28px;">
    	</div>
    </form>    <br><br>

    ';
    GoBackBtn('tohome');
} elseif ($action == 'fix') {
//	include($CROOTDIR."inc/scan.live.php");


$cmd="./fix.sh -a $username";
$output=shell_exec($cmd);

echo '<pre>'."\n\n";
print($output);
echo '</pre>';




	GoBackBtn('');
} 

// cPanel Footer
cpFooter();
?>