<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');

function PHP_CONF($debug=false) {
	if ($debug) {
		ini_set('display_errors',1);
		ini_set('display_startup_errors',1);
		error_reporting(-1);
	}
	set_time_limit(750);
	ini_set('default_socket_timeout', 750);
	ini_set('max_execution_time', 750);
	ini_set('memory_limit', "256M");
}

function Ajax_security() {
	if (@isset($_ENV['HTTP_X_REQUESTED_WITH']) && $_ENV['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
		if(@isset($_SERVER['HTTP_REFERER']) && @parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST)==$_SERVER['SERVER_NAME']) {
	    	if (@strpos($_SERVER["HTTP_ACCEPT"], 'application/json') !== false) {
		    	return false;
	    	} elseif (@strpos($_SERVER["HTTP_ACCEPT"], 'application/xml') !== false) {
		    	return false;
	    	} else {
	    		return true;
	    	}
	    } else {
		    return false;
		}
	} else {
	    return false;
	}
}


function GetUserLocale() {
	global $livecpapi;
	$userlocale = $livecpapi->api2('Locale','get_user_locale');
	return $userlocale['cpanelresult']['data'][0]['locale'];
}

function GetStdHeader() {
	global $livecpapi;
	$stdheader = $livecpapi->api1("Branding", "include", array("stdheader.html"));
	return $stdheader['cpanelresult']['data']['result'];
}

function GetStdFooter() {
	global $livecpapi;
	$stdfooter = $livecpapi->api1("Branding", "include", array("stdfooter.html"));
	return $stdfooter['cpanelresult']['data']['result'];
}

function SendToLog($action,$msg) {
	global $livecpapi;
	$logline = '['.$action.'] ['.$msg.']';
	$sendtolog = $livecpapi->api2('fixpermission','sendtolog',array("cpuser"=>getenv('USER'),"logline"=>$logline));
	if ($sendtolog['cpanelresult']['data'][0]['status'] == 0) {	
		return true;
	} else {
		return false;
	}
}

function SetLang() {
	global $CROOTDIR;
	$userLocalFile = $CROOTDIR.'lang/'.trim(GetUserLocale()).'.php';
	if (file_exists($userLocalFile)) {
		$userLangFile = $userLocalFile;
	} else {
		$userLangFile = $CROOTDIR.'lang/en.php';
	}
	return $userLangFile;
}

function UserTheme() {
	global $livecpapi;
	$statsbar = $livecpapi->api2('StatsBar','stat',array("display"=>"theme"));
	$cpTheme = trim($statsbar['cpanelresult']['data'][0]['value']);
	if (!empty($cpTheme)) {	
		return $cpTheme;
	} else {
		return false;
	}
}

function BaseDIR() {
	return $_ENV['cp_security_token'].'/3rdparty/fixpermission/';
}

function cpBase() {
	$UserTheme = UserTheme();
	if (isset($_ENV['cp_security_token'])) {
		$cptokuri = $_ENV['cp_security_token'].'/frontend/';
	} else {
		$cptokuri = '/frontend/';
	}
	if ($UserTheme) {
		return $cptokuri.$UserTheme.'/';
	} else {
		return false;
	}
}

function cpHeader() {
	global $livecpapi;
	$cpBase 	= cpBase();
	$UserTheme 	= UserTheme();
	// Print cPanel Std Header
	if ($UserTheme == 'paper_lantern') {
		print($livecpapi->header('Fix File Permission'));
	} else {
		print(GetStdHeader());
	}
	print('<script type="text/javascript" src="js/jquery.min.js"></script><link rel="stylesheet" href="css/style.css" media="all" />');
	echo '<script type="text/javascript">
		$(document).ready(function(){
		    $("#cpreturnlink").click(function(){
		        parent.history.back();
		        return false;
		    });
		});
	</script>
	<style type="text/css">
	.cpcprimary {
  background: #3498db;
  background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
  background-image: -moz-linear-gradient(top, #3498db, #2980b9);
  background-image: -ms-linear-gradient(top, #3498db, #2980b9);
  background-image: -o-linear-gradient(top, #3498db, #2980b9);
  background-image: linear-gradient(to bottom, #3498db, #2980b9);
  -webkit-border-radius: 6;
  -moz-border-radius: 6;
  border-radius: 6px;
  font-family: Arial;
  color: #ffffff;
  font-size: 20px;
  padding: 10px 20px 10px 20px;
  text-decoration: none;
}

.cpcprimary:hover {
  background: #3cb0fd;
  text-decoration: none;
}
	</style>
	';
	if ($UserTheme == 'paper_lantern') {
		// Fix paper_lantern User btn & img
		print('<script type="text/javascript">
			$("#lnkHeaderHome").prop("href", "'.$cpBase.'index.html");
			$("#sidebar_home").prop("href", "'.$cpBase.'index.html");
			$("#lnkQuickHome").prop("href", "'.$cpBase.'index.html");
			$("#lnkQuickDomains").prop("href", "'.$cpBase.'addon/index.html");
			$("#lnkQuickFilemgr").prop("href", "'.$cpBase.'filemanager/index.html?showhidden=1&dir=/public_html");
			$("#lnkQuickEmail").prop("href", "'.$cpBase.'mail/pops.html");
			$("#lnkUserPrefChangePwd").prop("href", "'.$cpBase.'passwd/index.html");
			$("#lnkUserPrefChangeLang").prop("href", "'.$cpBase.'setlang/index.html");
			$("#lnkUserPrefChangeStyle").prop("href", "'.$cpBase.'styleswitcher/index.html");
			$("#lnkUserPrefUpdateContactInfo").prop("href", "'.$cpBase.'contact/index.html");
			$("#lnkFooterHome").prop("href", "'.$cpBase.'index.html");
			$("#lnkFooterTrademark").prop("href", "'.$cpBase.'trademarks.html");
			$("#lnkFooterContact").prop("href", "'.$cpBase.'contact/contactinfo.html");
			$("#lnkMenu").prop("href", "'.$cpBase.'index.html");
			$("#lnkStats").prop("href", "'.$cpBase.'home/statistics.html");
			$("#lnkDashboard").prop("href", "'.$cpBase.'home/dashboard.html");
			$("#lnkHeaderNotifications").prop("href", "'.$cpBase.'home/notifications.html.tt");
			$("#lnkUserManager").prop("href", "'.$cpBase.'user_manager/index.html");
			$("#sidebar_user_manager").prop("href", "'.$cpBase.'user_manager/index.html");
		</script>');
	} elseif ($UserTheme == 'x4' OR $UserTheme == 'x4mail') {
		// Fix x4 User btn & img
		print('<script type="text/javascript">
			$("#headerMobileHome").prop("href", "'.$cpBase.'index.html");
			$("#headerHome").prop("href", "'.$cpBase.'index.html");
		</script>');
	} elseif ($UserTheme == 'x3' OR $UserTheme == 'x3mail') {
		// Fix x3 User btn & img
		print('<script type="text/javascript">
			$("#heading-home_off a:first").prop("href", "'.$cpBase.'index.html");
		</script>');
	}
}

function cpFooter() {
	global $livecpapi;
	$cpBase 	= cpBase();
	$UserTheme 	= UserTheme();
	// Print cPanel Std Footer
	if ($UserTheme == 'paper_lantern') {
		print($livecpapi->footer());
	} else {
		print(GetStdFooter());
	}
	if ($UserTheme == 'paper_lantern') {
		// Fix paper_lantern User btn & img
		print('	<script type="text/javascript">
			$("#lnkFooterHome").prop("href", "'.$cpBase.'index.html");
			$("#lnkFooterTrademark").prop("href", "'.$cpBase.'trademarks.html");
			$("#lnkFooterContact").prop("href", "'.$cpBase.'contact/contactinfo.html");
		</script>');
	} elseif ($UserTheme == 'x4' OR $UserTheme == 'x4mail') {
		// Fix x4 User btn & img
		print('<script type="text/javascript">
			$("#lnkFooterHome").prop("href", "'.$cpBase.'index.html");
			$("#lnkFooterTrademark").prop("href", "'.$cpBase.'trademarks.html");
			$("#lnkFooterContact").prop("href", "'.$cpBase.'unavailable.html?PageName=Contact_Page");
		</script>');
	} elseif ($UserTheme == 'x3' OR $UserTheme == 'x3mail') {
		// Fix x3 User btn & img
		print('	<script type="text/javascript">
			$("#heading-bottom_bg ul a[href=\'index.html\']").prop("href", "'.$cpBase.'index.html");
			$("#heading-bottom_bg ul a[href=\'trademarks.html\']").prop("href", "'.$cpBase.'trademarks.html");
			$("#heading-bottom_bg ul a[href$=\'/frontend/x3/branding//stdfooter.html\']").prop("href", "'.$cpBase.'help.html?url=/frontend/x3/index.html");
			$("#heading-bottom_bg ul a[href=\'contact/contactinfo.html\']").prop("href", "'.$cpBase.'contact/contactinfo.html");
			$("#helplinks ul a[href=\'tutorial.html\']").prop("href", "'.$cpBase.'tutorial.html");
			$("#helplinks ul a[href=\'contact/contactinfo.html\']").prop("href", "'.$cpBase.'contact/contactinfo.html");
		</script>');
	}
}

function GoBackBtn($flag) {
	global $LANG;
	if ($flag == 'tostart') {
		$aID 	= 'gobacktostart';
		$aHREF 	= BaseDIR().'index.live.php';
		$aTEXT 	= $LANG['gobacktobtn'];
	} elseif ($flag == 'tohome') {
		$aID 	= 'gobacktohome';
		$aHREF 	= cpBase().'index.html';
		$aTEXT 	= $LANG['gobacktohbtn'];
	} else {
		$aHREF 	= '#';
		$aID 	= 'cpreturnlink';
		$aTEXT 	= $LANG['gobackbtn'];
	} 
	echo '<div class="return-link"><a id="'.$aID.'" href="'.$aHREF.'"><span class="glyphicon glyphicon-circle-arrow-left"></span> '.$aTEXT.'</a></div>';
}


?>
