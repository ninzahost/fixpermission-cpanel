<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');

$CROOTDIR = '/usr/local/cpanel/base/3rdparty/fixpermission/';
require_once("/usr/local/cpanel/php/cpanel.php");
$livecpapi = new CPANEL();
require_once($CROOTDIR.'inc/func.inc.php');
if (isset($_GET['action'])) {$action = trim($_GET['action']);} else {$action = '';}
PHP_CONF();
?>