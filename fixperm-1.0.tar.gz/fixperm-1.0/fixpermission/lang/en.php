<?php
if (!isset($_ENV['cp_security_token']))	die('This file can be accessed only by CPPHP');

$LANG = array();
$LANG['gobackbtn'] = 'Go back';
$LANG['gobacktobtn'] = 'Go back to start';
$LANG['gobacktohbtn'] = 'Go back to home';
$LANG['homedes'] = 'A script to fix permissions and ownership, on files and directories, for cPanel accounts.';
$LANG['homebtn'] = 'Fix Now';
?>